# Real-data extension dataset for stochastic volatility project

Created from a public GitHub-hosted volatility dataset derived from the Oxford-Man Realized Library processing format.

Files:
- spx_returns_realized_volatility_2000_2021.csv: cleaned S&P 500 data for the project.
- spx_oxfordman_raw_subset.csv: SPX-only raw subset with original column names.
- volatility_tft_oxfordman.csv: full raw volatility dataset downloaded from the tft-forecast repository; large file, all symbols.

Recommended columns for our particle-filter extension:
- Y_j = open_to_close_return
- realized volatility proxy = realized_volatility_5min_subsampled = sqrt(realized_variance_5min_subsampled)
- log realized variance proxy = log_realized_variance_5min_subsampled

Important caveat:
Realized volatility is a high-frequency-data proxy for latent volatility, not the true hidden stochastic volatility X_j. In real data, true latent volatility is not observed.

SPX cleaned data summary:
- rows: 5358
- date range: 2000-01-03 to 2021-05-18
- missing values by column:
date                                     0
symbol                                   0
open_to_close_return                     0
close_to_close_log_return                1
open_price                               0
close_price                              0
realized_variance_5min_subsampled        0
realized_volatility_5min_subsampled      0
realized_variance_5min                   0
realized_volatility_5min                 0
realized_kernel_parzen                   0
realized_kernel_volatility_parzen        0
num_intraday_observations                0
log_realized_variance_5min_subsampled    0
